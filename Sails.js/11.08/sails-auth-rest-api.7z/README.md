Requirements

sails generate controller Home
sails generate model user
sails generate controller auth
npm install passport passport-local passport-strategy connect-mongo sails-mongo bcrypt-nodejs
npm install
